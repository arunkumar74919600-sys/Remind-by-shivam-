package com.shivam.remindbyshivam

import android.app.*
import android.content.*
import android.os.Build
import java.util.Calendar

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val habit = intent.getStringExtra("habit") ?: "Your habit"
        val repeat = intent.getStringExtra("repeat") ?: "Every day"
        val hour = intent.getIntExtra("hour", 9)
        val minute = intent.getIntExtra("minute", 0)
        val id = intent.getIntExtra("id", 1)

        val channelId = "habit_reminders"
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        if (Build.VERSION.SDK_INT >= 26) {
            manager.createNotificationChannel(
                NotificationChannel(channelId, "Habit Reminders", NotificationManager.IMPORTANCE_HIGH)
            )
        }

        val notification = Notification.Builder(context, channelId)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("⏰ Remind by Shivam")
            .setContentText("Time for: $habit")
            .setAutoCancel(true)
            .build()

        manager.notify(id, notification)

        // Schedule the next alarm for daily habits.
        if (repeat == "Every day") {
            val next = Calendar.getInstance().apply {
                add(Calendar.DAY_OF_YEAR, 1)
                set(Calendar.HOUR_OF_DAY, hour)
                set(Calendar.MINUTE, minute)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
            }
            val nextIntent = Intent(context, AlarmReceiver::class.java).apply {
                putExtra("habit", habit)
                putExtra("repeat", repeat)
                putExtra("hour", hour)
                putExtra("minute", minute)
                putExtra("id", id)
            }
            val pending = PendingIntent.getBroadcast(
                context, id, nextIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            context.getSystemService(AlarmManager::class.java)
                .setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next.timeInMillis, pending)
        }
    }
}
