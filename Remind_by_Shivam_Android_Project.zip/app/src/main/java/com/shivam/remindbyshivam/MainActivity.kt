package com.shivam.remindbyshivam

import android.app.*
import android.content.*
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.*
import java.util.Calendar

class MainActivity : Activity() {
    private lateinit var habitName: EditText
    private lateinit var timePicker: TimePicker
    private lateinit var repeatSpinner: Spinner
    private lateinit var status: TextView
    private lateinit var habitList: LinearLayout

    private val prefs by lazy { getSharedPreferences("habits", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        habitName = findViewById(R.id.habitName)
        timePicker = findViewById(R.id.timePicker)
        repeatSpinner = findViewById(R.id.repeatSpinner)
        status = findViewById(R.id.status)
        habitList = findViewById(R.id.habitList)

        repeatSpinner.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item,
            arrayOf("Every day", "Weekdays", "Weekends")
        )

        if (android.os.Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 10)
        }

        findViewById<Button>(R.id.addButton).setOnClickListener { addHabit() }
        renderHabits()
    }

    private fun addHabit() {
        val name = habitName.text.toString().trim()
        if (name.isEmpty()) {
            habitName.error = "Habit ka naam likho"
            return
        }

        if (android.os.Build.VERSION.SDK_INT >= 31) {
            val am = getSystemService(AlarmManager::class.java)
            if (!am.canScheduleExactAlarms()) {
                startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                    Uri.parse("package:$packageName")))
                Toast.makeText(this, "Exact alarm permission allow karo.", Toast.LENGTH_LONG).show()
                return
            }
        }

        val hour = timePicker.hour
        val minute = timePicker.minute
        val repeat = repeatSpinner.selectedItem.toString()
        val id = System.currentTimeMillis().toInt()

        val intent = Intent(this, AlarmReceiver::class.java).apply {
            putExtra("habit", name)
            putExtra("id", id)
            putExtra("repeat", repeat)
            putExtra("hour", hour)
            putExtra("minute", minute)
        }

        val pending = PendingIntent.getBroadcast(
            this, id, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val calendar = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
        }

        getSystemService(AlarmManager::class.java)
            .setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, calendar.timeInMillis, pending)

        prefs.edit().putString("habit_$id", "$name|$hour|$minute|$repeat").apply()

        status.text = "✅ $name\n⏰ $repeat · %02d:%02d".format(hour, minute)
        habitName.text.clear()
        renderHabits()
    }

    private fun renderHabits() {
        habitList.removeAllViews()
        prefs.all.entries.sortedBy { it.key }.forEach { entry ->
            val parts = entry.value.toString().split("|")
            if (parts.size < 4) return@forEach
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(0, 14, 0, 14)
            }
            val info = TextView(this).apply {
                text = "${parts[0]}\n⏰ %02d:%02d · ${parts[3]}".format(parts[1].toInt(), parts[2].toInt())
                textSize = 16f
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
            }
            val done = Button(this).apply {
                text = "✓ Done"
                setOnClickListener {
                    text = "✓ Done!"
                    isEnabled = false
                }
            }
            val delete = Button(this).apply {
                text = "Delete"
                setOnClickListener {
                    prefs.edit().remove(entry.key).apply()
                    renderHabits()
                }
            }
            row.addView(info)
            row.addView(done)
            row.addView(delete)
            habitList.addView(row)
        }
    }
}
