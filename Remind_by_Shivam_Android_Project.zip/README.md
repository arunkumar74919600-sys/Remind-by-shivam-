# Remind by Shivam

Simple Android habit + alarm reminder app.

Features:
- Habit name
- Reminder time
- Every day / weekdays / weekends selection
- Android notification alarm
- Habit list
- Mark Done
- Delete habit
- Exact alarm permission handling

Open in Android Studio and build an APK.
